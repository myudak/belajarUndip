/*File    	: boolean.h*/
/*Deskripsi : Header fungsi boolean */

/* Kamus */
#ifndef boolean_H
#define boolean_H
#define true 1
#define false 0
#define boolean unsigned char
#endif
